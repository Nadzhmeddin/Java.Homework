package Homework6;

import java.util.ArrayList;

// особенности кошек
public class Features {

    String awards;
    String pedigree;
    Boolean disability;
    String illness;
    String area;
    String category;


    // Вывод информации в строку. 
    @Override
    public String toString() {
        String res = String.format("Особенности кота:\n Награды: %s;\n Родословная: %s;\n Инвалидность: %b;\n Заболевания: %s;\n Среда обитания: %s;\n Категория: %s.\n", awards, pedigree, disability, illness, area, category);
        return res;
    }
}
