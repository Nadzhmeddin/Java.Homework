package Homework6;

public class Basicinfocat {
    int id;
    String name;
    String breed;
    int age;
    Boolean inject;
    String gender;
    String color;


    // Вывод информации в строку.
    @Override
    public String toString() {
        String res = String.format("Info about cat:\n id: %d;\n name: %s;\n breed: %s;\n age: %d;\n inject: %b;\n gender: %s;\n color: %s.\n",id, name, breed, age, inject, gender, color);
        return res;
    }

    // Метод сравнивания котов.
    @Override
    public boolean equals(Object o) {
        Basicinfocat t = (Basicinfocat) o;
        return id == t.id && name == t.name;
    }
}

