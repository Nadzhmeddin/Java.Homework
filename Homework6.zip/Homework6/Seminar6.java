package Homework6;

import java.util.ArrayList;

public class Seminar6 {
    public static void main(String[] args) {
        
        // info();
        // catFeatures();
    }


        // Базовая информация о коте в рамках ветеринарной книжки.
        static void info() {

        Basicinfocat cat1 = new Basicinfocat();
        cat1.id = 102;
        cat1.name = "Лу";
        cat1.breed = "Шотландец";
        cat1.age = 7;
        cat1.inject = true;
        cat1.gender = "male";
        cat1.color = "Белый";
        
        Basicinfocat cat2 = new Basicinfocat();
        cat2.id = 105;
        cat2.name = "Лис";
        cat2. breed = "Вислоухий";
        cat2.age = 5;
        cat2.inject = false;
        cat2.gender = "female";  
        cat2.color = "Серый";                                                       

        System.out.println(cat1.toString());
        System.out.println(cat2.toString());

    }

        // Особенности кота-пациента: 
        static void catFeatures() {
            Features cat1 = new Features();
            
            cat1.awards = ("Чемпион Европы среди малых кошек");
            cat1.pedigree = "Отец и Мать Чемпионы РФ";
            cat1.disability = true;
            cat1.illness = "Отсутствуют заболевания";
            cat1.area = "Центральная Россия";
            cat1.category = "Домашняя кошка";
            
            Features cat2 = new Features();

            cat2.awards = ("Чемпион Замбии среди диких кошек");
            cat2.pedigree = "Без родословной";
            cat2.disability = false;
            cat2.illness = "Заболевания ушей";
            cat2.area = "Центральная Африка";
            cat2.category = "Хищные кошки";

            System.out.println(cat1.toString());
            System.out.println(cat2.toString());
        }
        
}

